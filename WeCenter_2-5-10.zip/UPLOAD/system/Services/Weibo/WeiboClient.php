<?php

require_once AWS_PATH . 'Services/Weibo/WeiboOAuth.php';