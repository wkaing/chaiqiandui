<?php

$config['debug'] = false;	// 网站 Debug 模式
